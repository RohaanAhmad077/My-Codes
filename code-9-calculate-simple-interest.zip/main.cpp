/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>

using namespace std;

int main()
{
   float a,p,r,t;
   cout<<"Enter value of P:"<<endl; //float principle
   cout<<"Enter value of R:"<<endl; //float rate
   cout<<"Enter value of T:"<<endl; //float time
   cin>>p>>r>>t;  //simple interest=(p*r*t/100)
   a=p*r*t;
   cout<<"Simple interest is:"<<a/100;
 
   
   
    return 0;
}